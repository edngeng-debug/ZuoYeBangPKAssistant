作业帮PK助手 v1.4 诊断版
本版本用于验证 Android 无障碍服务能否正常启动。
项目根目录包含 settings.gradle.kts 和 app/build.gradle.kts。
