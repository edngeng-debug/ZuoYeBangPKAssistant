# 作业帮 PK 自动答题助手

Android 原生 Kotlin 示例工程。

## 开发环境

- Android Studio
- JDK 17
- Android SDK 35
- minSdk 26
- targetSdk 35

## 使用

1. 导入项目。
2. 等 Gradle 同步完成。
3. 连接 Android 手机并安装 APK。
4. 打开应用。
5. 开启“作业帮PK助手”的无障碍服务。
6. 回到应用点击“开始”并允许截屏。
7. 切换到作业帮 PK 题目页面。
8. 程序会截图 -> 裁剪左右数字 -> ML Kit OCR -> 二次确认 -> 无障碍滑动。
9. 胜利页优先通过无障碍节点寻找“安慰ta一下”和“继续PK”，找不到时使用缩放后的固定坐标。
10. 音量减键会尝试停止自动化；不同手机 ROM 对系统按键拦截存在差异，因此请保留应用里的停止按钮作为可靠停止方式。

## 重要

这是基于提供的 689×1536 截图、按 1080×2400 基准设计的初始版本。
如果实际手机截图显示数字没有落在 OCR 框内，修改 `Config.kt` 的 LEFT/RIGHT OCR 参数即可。

### 滑动规则

- 左 < 右：向左滑
- 左 > 右：向右滑
- 左 = 右：等待，不操作

### 胜利页

程序优先通过 AccessibilityNodeInfo 找按钮文字：
- 安慰ta一下
- 继续PK

找不到时才使用固定坐标点击。

## Android 15 注意事项

MediaProjection 使用前台服务，并声明：
- FOREGROUND_SERVICE
- FOREGROUND_SERVICE_MEDIA_PROJECTION

首次启动截屏会由系统弹出授权对话框。
# 作业帮 PK 助手 — GitHub 云端编译版

这个版本专门用于 GitHub Actions 云端编译，不需要 AndroidIDE、Termux 或本地 Android SDK。

## 最简单的使用方法

1. 在 GitHub 新建一个空仓库，例如 `ZuoYeBangPKAssistant`。
2. 把这个 ZIP 解压后，把里面的**所有文件和文件夹**上传到仓库根目录。
3. 打开仓库的 **Actions**。
4. 第一次如果看到提示，点击 **I understand my workflows, go ahead and enable them**。
5. 左侧选择 **Build APK**。
6. 点击 **Run workflow**。
7. 等待构建完成。
8. 点进这次运行记录，在页面底部 **Artifacts** 下载 `ZuoYeBangPKAssistant-debug-apk`。
9. 解压得到 `app-debug.apk`，安装到手机即可。

## 自动编译

以后向 `main` 或 `master` 分支提交代码时也会自动编译 APK。

## 编译环境

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 34
- targetSdk 34
- minSdk 26

Debug APK 使用 GitHub Actions 构建环境的 Android debug keystore 自动签名，可以直接安装测试。

## 注意

第一次构建需要从 Google Maven、Maven Central 下载 Android/Kotlin/ML Kit 依赖，因此需要等待几分钟。
