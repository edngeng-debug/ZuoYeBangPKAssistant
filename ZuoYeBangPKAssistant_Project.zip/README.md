# 作业帮PK助手 1.3 诊断版

这是一个最小化无障碍服务诊断工程。

本版本刻意移除了 OCR、MediaProjection、AutomationController、手势、截图和第三方依赖，只保留：
- 一个可启动的 Activity
- 一个 AccessibilityService
- 最小无障碍服务 XML 配置

目的：确认 Android 15 上无障碍服务本身能否正常启用。
