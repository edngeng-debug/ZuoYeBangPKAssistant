# 作业帮PK助手 - 截图专用诊断版 v1.4

本版本只测试 Android MediaProjection + ImageReader 截图链路。

不包含 OCR、自动答题、滑动、题目识别等功能。

测试步骤：
1. 安装 APK。
2. 打开应用。
3. 点击“开始截图测试”。
4. 同意系统录屏/投屏权限。
5. 查看通知是否显示“截图正常：已取得 N 帧”。

Logcat 关键标签：
- PKCaptureDiagnostic
- PKAccessibility

关键成功日志：
- SERVICE_CREATED
- DISPLAY WxH
- VIRTUAL_DISPLAY_CREATED
- FRAME_OK count=1
