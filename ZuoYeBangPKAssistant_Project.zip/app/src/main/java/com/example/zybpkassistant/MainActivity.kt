package com.example.zybpkassistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            text = "截图诊断版 v1.4\n\n先点击“开始截图测试”。\n系统会弹出录屏/投屏授权窗口。\n授权后程序尝试持续取得屏幕帧。"
            textSize = 17f
            setPadding(40, 50, 40, 30)
        }

        val button = Button(this).apply {
            text = "开始截图测试"
            setOnClickListener {
                val mgr = getSystemService(MediaProjectionManager::class.java)
                startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        }

        val stop = Button(this).apply {
            text = "停止截图测试"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "已停止截图服务"
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(button)
            addView(stop)
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return

        if (resultCode != RESULT_OK || data == null) {
            status.text = "截图授权：失败/取消"
            return
        }

        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
        }
        startForegroundService(serviceIntent)
        status.text = "截图授权成功，正在启动 ImageReader..."
    }

    companion object {
        private const val REQUEST_CAPTURE = 1001
    }
}
