package com.example.zybpkassistant

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        private var instance: MainActivity? = null

        fun updateStatus(text: String) {
            instance?.runOnUiThread {
                instance?.findViewById<TextView>(R.id.tvStatus)?.text = "状态：$text"
            }
        }

        fun updateResult(left: Int, right: Int) {
            instance?.runOnUiThread {
                instance?.findViewById<TextView>(R.id.tvResult)?.text =
                    "识别结果：$left ? $right"
            }
        }

        fun updateCount(count: Int) {
            instance?.runOnUiThread {
                instance?.findViewById<TextView>(R.id.tvCount)?.text =
                    "本轮：$count/${Config.QUESTIONS_PER_ROUND}"
            }
        }
    }

    private val projectionRequestCode = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        instance = this

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            startAutomation()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopAutomation()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionUi()
    }

    private fun refreshPermissionUi() {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        ).any { it.resolveInfo.serviceInfo.packageName == packageName }

        findViewById<TextView>(R.id.tvAccessibility).text =
            if (enabled) "无障碍服务：已开启" else "无障碍服务：未开启"
    }

    private fun startAutomation() {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        ).any { it.resolveInfo.serviceInfo.packageName == packageName }

        if (!enabled) {
            updateStatus("请先开启无障碍服务")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != projectionRequestCode ||
            resultCode != Activity.RESULT_OK ||
            data == null) {
            updateStatus("未获得截屏权限")
            return
        }

        AutomationController.start()

        val serviceIntent = Intent(this, CaptureService::class.java).apply {
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }

        startForegroundService(serviceIntent)
        updateStatus("自动答题已启动")
    }

    private fun stopAutomation() {
        AutomationController.stop()
        stopService(Intent(this, CaptureService::class.java))
        updateStatus("已停止")
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
