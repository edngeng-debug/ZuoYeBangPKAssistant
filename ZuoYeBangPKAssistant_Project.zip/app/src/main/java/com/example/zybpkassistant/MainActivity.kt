package com.example.zybpkassistant

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "作业帮PK助手\n\n1. 打开系统设置 → 无障碍\n2. 找到“作业帮PK助手（诊断版）”\n3. 尝试开启服务\n\n本版本仅用于测试无障碍服务是否能正常启动。"
            textSize = 18f
            setPadding(48, 80, 48, 48)
        }
        setContentView(text)
    }
}
