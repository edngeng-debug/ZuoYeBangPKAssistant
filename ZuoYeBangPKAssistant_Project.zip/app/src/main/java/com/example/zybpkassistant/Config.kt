package com.example.zybpkassistant

/**
 * 所有坐标以 1080×2400 为基准，运行时自动缩放。
 * 如果你的实际游戏界面有偏移，只需要修改这里。
 */
object Config {
    const val BASE_WIDTH = 1080f
    const val BASE_HEIGHT = 2400f

    // 数字 OCR 区域
    const val LEFT_X = 100f
    const val LEFT_Y = 720f
    const val LEFT_W = 300f
    const val LEFT_H = 180f

    const val RIGHT_X = 680f
    const val RIGHT_Y = 720f
    const val RIGHT_W = 300f
    const val RIGHT_H = 180f

    // 手写区滑动
    const val SWIPE_START_X = 540f
    const val SWIPE_START_Y = 1700f
    const val SWIPE_DISTANCE = 300f
    const val SWIPE_DURATION_MS = 120L

    // 胜利界面按钮
    const val COMFORT_X = 540f
    const val COMFORT_Y = 1355f
    const val CONTINUE_X = 850f
    const val CONTINUE_Y = 1495f

    const val OCR_CONFIRM_DELAY_MS = 90L
    const val AFTER_SWIPE_DELAY_MS = 600L
    const val COMFORT_WAIT_MS = 1000L
    const val CONTINUE_WAIT_MS = 2200L

    const val QUESTIONS_PER_ROUND = 10
}
