package com.example.zybpkassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Parcelable
import android.util.Log
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import kotlin.math.roundToInt

class CaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL_ID = "capture_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ocr = OcrEngine()

    @Volatile
    private var busy = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val resultData = intent?.getParcelableExtraCompat<Intent>(EXTRA_RESULT_DATA)

        startForegroundCompat()

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            MainActivity.updateStatus("截屏授权失败")
            stopSelf()
            return START_NOT_STICKY
        }

        startProjection(resultCode, resultData)
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        if (projection != null) return

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager

        projection = manager.getMediaProjection(resultCode, data)

        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.densityDpi

        imageReader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
        )

        imageReader!!.setOnImageAvailableListener({ reader ->
            if (!AutomationController.running || busy) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy = true

            scope.launch {
                try {
                    val bitmap = imageToBitmap(image)
                    image.close()

                    if (bitmap != null) {
                        processFrame(bitmap)
                        bitmap.recycle()
                    }
                } catch (e: Exception) {
                    Log.e("PKAssistant", "截图/OCR异常", e)
                } finally {
                    busy = false
                }
            }
        }, null)

        virtualDisplay = projection!!.createVirtualDisplay(
            "ZuoYeBangPKCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            null
        )

        MainActivity.updateStatus("截屏已启动")
    }

    private suspend fun processFrame(bitmap: Bitmap) {
        // 先检查胜利页，避免把结算界面中的数字当题目。
        AutomationController.checkVictoryAndClickButtons()
        if (!AutomationController.running) return

        val dm = resources.displayMetrics
        val sx = bitmap.width / Config.BASE_WIDTH
        val sy = bitmap.height / Config.BASE_HEIGHT

        fun rect(x: Float, y: Float, w: Float, h: Float) = android.graphics.Rect(
            (x * sx).roundToInt(),
            (y * sy).roundToInt(),
            ((x + w) * sx).roundToInt(),
            ((y + h) * sy).roundToInt()
        )

        val leftRect = rect(Config.LEFT_X, Config.LEFT_Y, Config.LEFT_W, Config.LEFT_H)
        val rightRect = rect(Config.RIGHT_X, Config.RIGHT_Y, Config.RIGHT_W, Config.RIGHT_H)

        val left = ocr.recognize(bitmap, leftRect)
        val right = ocr.recognize(bitmap, rightRect)

        MainActivity.updateResult(left, right)

        if (left < 0 || right < 0) {
            MainActivity.updateStatus("OCR失败，等待下一帧")
            return
        }

        // 如果上一帧已经保存了同样候选值，则确认并执行。
        val candidate = AutomationController.takeCandidate()
        if (candidate != null) {
            if (candidate.first == left && candidate.second == right) {
                AutomationController.onConfirmedNumbers(left, right)
                return
            }
        }

        AutomationController.onNumbers(left, right)
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmapWidth = image.width + rowPadding / pixelStride
        val bitmap = Bitmap.createBitmap(
            bitmapWidth,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        return if (bitmapWidth == image.width) {
            bitmap
        } else {
            val cropped = Bitmap.createBitmap(
                bitmap, 0, 0, image.width, image.height
            )
            bitmap.recycle()
            cropped
        }
    }

    private fun startForegroundCompat() {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("作业帮 PK 助手")
            .setContentText("正在进行屏幕识别")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        startForeground(
            NOTIFICATION_ID,
            notification,
            if (Build.VERSION.SDK_INT >= 29)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else 0
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PK助手截屏",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        ocr.close()
        imageReader?.close()
        virtualDisplay?.release()
        projection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private inline fun <reified T : Parcelable> Intent.getParcelableExtraCompat(key: String): T? {
        return if (Build.VERSION.SDK_INT >= 33) {
            getParcelableExtra(key, T::class.java)
        } else {
            getParcelableExtra(key)
        }
    }
}
