package com.example.zybpkassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var frameCount = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification("正在进行截图诊断"))
        Log.i(TAG, "SERVICE_CREATED")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)

        if (resultCode < 0 || data == null) {
            Log.e(TAG, "CAPTURE_START_FAILED: missing permission data")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            projection = manager.getMediaProjection(resultCode, data)

            val metrics = DisplayMetrics()
            val wm = getSystemService(WindowManager::class.java)
            wm.defaultDisplay.getRealMetrics(metrics)

            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            Log.i(TAG, "DISPLAY ${width}x${height} density=$density")

            reader = ImageReader.newInstance(
                width,
                height,
                PixelFormat.RGBA_8888,
                2
            )

            reader!!.setOnImageAvailableListener({ ir ->
                val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    frameCount++
                    if (frameCount == 1 || frameCount % 30 == 0) {
                        Log.i(TAG, "FRAME_OK count=$frameCount size=${image.width}x${image.height}")
                    }
                    updateNotification("截图正常：已取得 $frameCount 帧")
                } catch (t: Throwable) {
                    Log.e(TAG, "FRAME_PROCESS_ERROR", t)
                } finally {
                    image.close()
                }
            }, null)

            projection!!.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.i(TAG, "PROJECTION_STOPPED")
                    updateNotification("MediaProjection 已停止")
                    cleanup()
                    stopSelf()
                }
            }, null)

            projection!!.createVirtualDisplay(
                "ZuoYeBangPKAssistantDiagnostic",
                width,
                height,
                density,
                0,
                reader!!.surface,
                null,
                null
            )

            Log.i(TAG, "VIRTUAL_DISPLAY_CREATED")
            updateNotification("VirtualDisplay 已创建，等待屏幕帧")
        } catch (t: Throwable) {
            Log.e(TAG, "CAPTURE_START_ERROR", t)
            updateNotification("截图启动失败：" + (t.message ?: "unknown"))
            cleanup()
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, notification(text))
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("作业帮PK助手截图诊断")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()

    private fun cleanup() {
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
    }

    override fun onDestroy() {
        cleanup()
        Log.i(TAG, "SERVICE_DESTROYED")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "截图诊断",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val TAG = "PKCaptureDiagnostic"
        private const val CHANNEL_ID = "capture_diagnostic"
        private const val NOTIFICATION_ID = 1001
    }
}
