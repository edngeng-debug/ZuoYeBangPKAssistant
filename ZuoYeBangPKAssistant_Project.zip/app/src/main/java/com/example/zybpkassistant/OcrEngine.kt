package com.example.zybpkassistant

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/**
 * 只识别数字区域，减少背景图案干扰。
 */
class OcrEngine {

    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bitmap: Bitmap, rect: Rect): Int {
        val safe = Rect(
            rect.left.coerceAtLeast(0),
            rect.top.coerceAtLeast(0),
            rect.right.coerceAtMost(bitmap.width),
            rect.bottom.coerceAtMost(bitmap.height)
        )

        if (safe.width() <= 0 || safe.height() <= 0) return -1

        val crop = Bitmap.createBitmap(
            bitmap,
            safe.left,
            safe.top,
            safe.width(),
            safe.height()
        )

        return try {
            val result = recognizer.process(InputImage.fromBitmap(crop, 0)).await()
            parseNumber(result.text)
        } finally {
            crop.recycle()
        }
    }

    private fun parseNumber(text: String): Int {
        // 题目目前按整数处理；允许 OCR 把负号识别出来。
        val cleaned = text
            .replace("O", "0", ignoreCase = true)
            .replace("I", "1", ignoreCase = true)
            .replace("l", "1")
            .replace(" ", "")
            .trim()

        val match = Regex("""-?\d+""").find(cleaned) ?: return -1
        return match.value.toIntOrNull() ?: -1
    }

    fun close() {
        recognizer.close()
    }
}
