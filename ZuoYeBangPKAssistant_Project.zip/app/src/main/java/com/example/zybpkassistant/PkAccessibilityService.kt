package com.example.zybpkassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PkAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        AutomationController.accessibilityService = this
        MainActivity.updateStatus("无障碍服务已连接")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!AutomationController.running) return

        // 结算页按钮通常会出现在无障碍节点树中。
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            AutomationController.checkVictoryAndClickButtons()
        }
    }

    override fun onInterrupt() {
        // 系统中断时停止自动化，避免继续操作。
        AutomationController.stop()
    }

    /**
     * 音量减键作为紧急停止键。
     * Android 对系统按键的分发可能因 ROM 而异，因此主界面停止按钮仍保留。
     */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == KeyEvent.ACTION_DOWN) {
            AutomationController.stop()
            return true
        }
        return super.onKeyEvent(event)
    }

    fun swipeTo(direction: String) {
        val dm = resources.displayMetrics
        val sx = Config.SWIPE_START_X / Config.BASE_WIDTH * dm.widthPixels
        val sy = Config.SWIPE_START_Y / Config.BASE_HEIGHT * dm.heightPixels
        val distance = Config.SWIPE_DISTANCE / Config.BASE_WIDTH * dm.widthPixels

        val ex = if (direction == "左") sx - distance else sx + distance

        val path = Path().apply {
            moveTo(sx, sy)
            lineTo(ex, sy)
        }

        val stroke = GestureDescription.StrokeDescription(
            path,
            0,
            Config.SWIPE_DURATION_MS
        )
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun clickScaled(baseX: Float, baseY: Float) {
        val dm = resources.displayMetrics
        click(baseX / Config.BASE_WIDTH * dm.widthPixels,
            baseY / Config.BASE_HEIGHT * dm.heightPixels)
    }

    private fun click(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }

    fun hasText(text: String): Boolean = findText(rootInActiveWindow, text) != null

    fun clickText(text: String): Boolean {
        val node = findText(rootInActiveWindow, text) ?: return false
        return clickNode(node)
    }

    private fun findText(node: AccessibilityNodeInfo?, text: String): AccessibilityNodeInfo? {
        if (node == null) return null

        val nodeText = node.text?.toString()
        val desc = node.contentDescription?.toString()

        if (nodeText?.contains(text) == true || desc?.contains(text) == true) {
            return node
        }

        for (i in 0 until node.childCount) {
            val result = findText(node.getChild(i), text)
            if (result != null) return result
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    override fun onDestroy() {
        if (AutomationController.accessibilityService === this) {
            AutomationController.accessibilityService = null
        }
        super.onDestroy()
    }
}
