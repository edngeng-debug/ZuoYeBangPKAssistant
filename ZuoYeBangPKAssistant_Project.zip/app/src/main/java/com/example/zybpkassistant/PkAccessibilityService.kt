package com.example.zybpkassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

/**
 * 极简、抗崩溃的无障碍服务：只负责接收事件和执行点击/滑动。
 * OCR/截图等重任务全部放在 CaptureService 中，避免无障碍服务启动时发生连锁故障。
 */
class PkAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "PKAccessibility"
    }

    override fun onServiceConnected() {
        try {
            super.onServiceConnected()
            AutomationController.accessibilityService = this
            MainActivity.updateStatus("无障碍服务已连接")
            Log.i(TAG, "Accessibility service connected")
        } catch (t: Throwable) {
            // 不让初始化异常把 AccessibilityService 进程直接打死。
            Log.e(TAG, "onServiceConnected failed", t)
            AutomationController.accessibilityService = this
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 服务开启后但尚未开始自动化时，完全不处理事件。
        if (!AutomationController.running) return

        try {
            val type = event?.eventType ?: return
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                AutomationController.checkVictoryAndClickButtons()
            }
        } catch (t: Throwable) {
            // 单个事件处理失败绝不能导致无障碍服务被系统判定为故障。
            Log.e(TAG, "Accessibility event failed", t)
        }
    }

    override fun onInterrupt() {
        try {
            AutomationController.stop()
        } catch (t: Throwable) {
            Log.e(TAG, "onInterrupt failed", t)
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        return try {
            if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
                event.action == KeyEvent.ACTION_DOWN) {
                AutomationController.stop()
                true
            } else {
                super.onKeyEvent(event)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "onKeyEvent failed", t)
            false
        }
    }

    fun swipeTo(direction: String) {
        try {
            val dm = resources.displayMetrics
            val sx = Config.SWIPE_START_X / Config.BASE_WIDTH * dm.widthPixels
            val sy = Config.SWIPE_START_Y / Config.BASE_HEIGHT * dm.heightPixels
            val distance = Config.SWIPE_DISTANCE / Config.BASE_WIDTH * dm.widthPixels
            val ex = if (direction == "左") sx - distance else sx + distance

            val path = Path().apply {
                moveTo(sx, sy)
                lineTo(ex, sy)
            }
            val stroke = GestureDescription.StrokeDescription(
                path, 0, Config.SWIPE_DURATION_MS
            )
            dispatchGesture(
                GestureDescription.Builder().addStroke(stroke).build(),
                null,
                null
            )
        } catch (t: Throwable) {
            Log.e(TAG, "swipe failed", t)
            MainActivity.updateStatus("滑动执行失败")
        }
    }

    fun clickScaled(baseX: Float, baseY: Float) {
        try {
            val dm = resources.displayMetrics
            click(
                baseX / Config.BASE_WIDTH * dm.widthPixels,
                baseY / Config.BASE_HEIGHT * dm.heightPixels
            )
        } catch (t: Throwable) {
            Log.e(TAG, "clickScaled failed", t)
        }
    }

    private fun click(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }

    fun hasText(text: String): Boolean {
        return try {
            findText(rootInActiveWindow, text) != null
        } catch (t: Throwable) {
            Log.e(TAG, "hasText failed", t)
            false
        }
    }

    fun clickText(text: String): Boolean {
        return try {
            val node = findText(rootInActiveWindow, text) ?: return false
            clickNode(node)
        } catch (t: Throwable) {
            Log.e(TAG, "clickText failed", t)
            false
        }
    }

    private fun findText(node: AccessibilityNodeInfo?, text: String): AccessibilityNodeInfo? {
        if (node == null) return null

        val nodeText = node.text?.toString()
        val desc = node.contentDescription?.toString()
        if (nodeText?.contains(text) == true || desc?.contains(text) == true) return node

        // 防止异常节点树导致递归爆栈/访问失效节点。
        val count = node.childCount.coerceAtMost(100)
        for (i in 0 until count) {
            val child = try { node.getChild(i) } catch (_: Throwable) { null }
            val result = findText(child, text)
            if (result != null) return result
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 30) {
            try {
                if (current.isClickable) {
                    return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                current = current.parent
            } catch (_: Throwable) {
                return false
            }
        }
        return false
    }

    override fun onDestroy() {
        try {
            if (AutomationController.accessibilityService === this) {
                AutomationController.accessibilityService = null
            }
        } catch (t: Throwable) {
            Log.e(TAG, "onDestroy failed", t)
        }
        super.onDestroy()
    }
}
