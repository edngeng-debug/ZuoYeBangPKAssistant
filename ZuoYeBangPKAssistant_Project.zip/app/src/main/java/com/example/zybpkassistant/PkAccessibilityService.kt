package com.example.zybpkassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

/** Minimal diagnostic accessibility service. Keep startup path dependency-free. */
class PkAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("PKAccessibility", "SERVICE_CONNECTED")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty in diagnostic build.
    }

    override fun onInterrupt() {
        Log.i("PKAccessibility", "SERVICE_INTERRUPTED")
    }
}
