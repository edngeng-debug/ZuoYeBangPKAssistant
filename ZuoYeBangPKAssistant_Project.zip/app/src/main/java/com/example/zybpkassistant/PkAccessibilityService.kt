package com.example.zybpkassistant

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class PkAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "SERVICE_CONNECTED")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Diagnostic build: deliberately empty.
    }

    override fun onInterrupt() {
        Log.i(TAG, "SERVICE_INTERRUPTED")
    }

    companion object {
        private const val TAG = "PKAccessibility"
    }
}
