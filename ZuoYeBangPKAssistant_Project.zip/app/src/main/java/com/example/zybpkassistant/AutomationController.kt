package com.example.zybpkassistant

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 自动答题状态机。
 * CaptureService 负责截图/OCR，本类负责把 OCR 结果交给无障碍服务执行。
 */
object AutomationController {
    private const val TAG = "PKAssistant"

    @Volatile
    var accessibilityService: PkAccessibilityService? = null

    @Volatile
    var running = false

    private val processing = AtomicBoolean(false)
    private val victoryHandling = AtomicBoolean(false)
    private var job: Job? = null

    var answeredCount: Int = 0
        private set

    fun start() {
        running = true
        answeredCount = 0
        processing.set(false)
        victoryHandling.set(false)
        Candidate.ready = false
        postStatus("运行中")
    }

    fun stop() {
        running = false
        processing.set(false)
        victoryHandling.set(false)
        Candidate.ready = false
        job?.cancel()
        job = null
        postStatus("已停止")
    }

    /**
     * 一轮截图得到左右数字后调用。
     * 两次 OCR 结果需要一致，降低单帧误识别导致答错的概率。
     */
    fun onNumbers(left: Int, right: Int) {
        if (!running || left < 0 || right < 0) return
        if (!processing.compareAndSet(false, true)) return

        job?.cancel()
        job = CoroutineScope(Dispatchers.Main).launch {
            try {
                delay(Config.OCR_CONFIRM_DELAY_MS)

                // 第二次确认由 CaptureService 再次触发。
                // 这里先保存候选值。
                Candidate.left = left
                Candidate.right = right
                Candidate.ready = true
            } finally {
                processing.set(false)
            }
        }
    }

    fun onConfirmedNumbers(left: Int, right: Int) {
        if (!running || left < 0 || right < 0) return
        if (left == right) {
            postStatus("识别到相等数字：$left = $right，等待下一帧")
            return
        }

        val service = accessibilityService ?: run {
            postStatus("无障碍服务未连接")
            return
        }

        if (answeredCount >= Config.QUESTIONS_PER_ROUND) return

        answeredCount++
        val direction = if (left < right) "左" else "右"
        postResult(left, right)
        postCount(answeredCount)

        service.swipeTo(direction)
        postStatus("第 ${answeredCount} 题：向${direction}滑")

        // 结束本题后的处理交给胜利界面检测。
        job?.cancel()
        job = CoroutineScope(Dispatchers.Main).launch {
            delay(Config.AFTER_SWIPE_DELAY_MS)
            processing.set(false)
        }
    }

    fun checkVictoryAndClickButtons() {
        if (!running) return
        val service = accessibilityService ?: return
        if (!victoryHandling.compareAndSet(false, true)) return

        // 优先使用 AccessibilityNodeInfo 的按钮文本，不依赖 OCR 找按钮。
        if (service.hasText("安慰ta一下")) {
            job?.cancel()
            job = CoroutineScope(Dispatchers.Main).launch {
                try {
                    postStatus("检测到胜利界面，点击「安慰ta一下」")
                    if (!service.clickText("安慰ta一下")) {
                        service.clickScaled(Config.COMFORT_X, Config.COMFORT_Y)
                    }
                    delay(Config.COMFORT_WAIT_MS)

                    postStatus("点击「继续PK」")
                    if (!service.clickText("继续PK")) {
                        service.clickScaled(Config.CONTINUE_X, Config.CONTINUE_Y)
                    }

                    delay(Config.CONTINUE_WAIT_MS)
                    answeredCount = 0
                    postCount(0)
                    postStatus("等待下一轮")
                } catch (e: Exception) {
                    Log.e(TAG, "结算处理失败", e)
                    postStatus("结算处理异常：${e.message}")
                } finally {
                    victoryHandling.set(false)
                }
            }
        } else {
            victoryHandling.set(false)
        }
    }

    fun isCandidateReady(): Boolean = Candidate.ready

    fun takeCandidate(): Pair<Int, Int>? {
        if (!Candidate.ready) return null
        Candidate.ready = false
        return Candidate.left to Candidate.right
    }

    private object Candidate {
        var left = -1
        var right = -1
        var ready = false
    }

    private fun postStatus(s: String) {
        MainActivity.updateStatus(s)
    }

    private fun postResult(l: Int, r: Int) {
        MainActivity.updateResult(l, r)
    }

    private fun postCount(c: Int) {
        MainActivity.updateCount(c)
    }
}
