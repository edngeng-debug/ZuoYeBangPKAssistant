plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.zybpkassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.zybpkassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.4-screenshot-diagnostic"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
